import React from "react";

function FoodItem(props) {

  const read = (event) => {
    const desc = event.currentTarget.previousElementSibling;
    desc.classList.toggle("expanded");
    const parent = event.currentTarget.parentElement.parentElement
    parent.classList.toggle('extended')
    console.log(parent)
    event.currentTarget.textContent = desc.classList.contains("expanded") ? "read less" : "Read More";
  };
  return (
    <div className="single-food">
      <div className="img">
        <img src={props.img} alt={props.title} />
      </div>
      <div className="title-price">
        <h3>{props.title}</h3>
        <p>{props.price}</p>
      </div>
      <div className="food-desc-container">
        <p className="food-desc">{props.desc}</p>
        <button onClick={read} className="read-more-btn">
          Read More
        </button>
      </div>
    </div>
  );
}

export default FoodItem;


